weapons = {
    rock,
    paper,
    scissors
}