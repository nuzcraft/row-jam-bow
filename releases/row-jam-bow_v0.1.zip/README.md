# row-jam-bow
Rock-Paper-Scissors Broughlike

### v0.1 "The First"
Basic shell from Super Turtle Man. Changes:
- name... of course
- enemies can damage each other
- rock, paper, and scissors based enemies
- player is rock type
- rock is weak to paper is weak to scissors is weak to rock
